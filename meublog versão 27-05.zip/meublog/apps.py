from django.apps import AppConfig


class MeublogConfig(AppConfig):
    name = 'meublog'
